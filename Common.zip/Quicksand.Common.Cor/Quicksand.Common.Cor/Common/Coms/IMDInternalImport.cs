﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Quicksand.Common.Cor.Common
{
    [ComImport]
    [Guid("CE0F34ED-BBC6-11d2-941E-0000F8083460")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IMDInternalImport
    {
       
    }

}
