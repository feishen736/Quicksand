﻿using Quicksand.Common.Aop;
using Quicksand.Common.Aop.Common;
using Quicksand.Common.Cor;
using Quicksand.Common.Cor.Common;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Quicksand.Common.App
{
    class Program
    {
        static Program()
        {
            CorJitManager.AttachJitCompiler(new InterceptionProvider());
        }

        static void Main(string[] args)
        {
            TestClass.TestMethod();
            Console.ReadLine();
        }
    }

    class TestClass
    {
        [TestAttribute]
        public static void TestMethod()
        {
            // 注入前编码
            Console.WriteLine("测试方法");

            //// 注入后编码
            //var attr = MethodInfo.GetCurrentMethod().GetCustomAttribute<TestAttribute>();
            //var args = new ExecutionArgs();

            //try
            //{
            //    attr.OnEntryMethod(args);

            //    if (args.Status.HasFlag(ExecutionStatus.ExecutionFailed))
            //        return;
            //    if (!args.Status.HasFlag(ExecutionStatus.EntryMethodSuccess))
            //        return;

            //    Console.WriteLine("测试方法");
            //}
            //catch (Exception err)
            //{
            //    args.Exception = err;
            //    attr.OnErrorMethod(args);
            //}
            //finally
            //{
            //    attr.OnExitsMethod(args);
            //}
        }
    }

    class TestAttribute : MemberInterceptionAttribute
    {
        public override void OnEntryMethod(ExecutionArgs args)
        {
            Console.WriteLine("进入方法");
            // 放行
            args.Status = ExecutionStatus.EntryMethodSuccess;
        }

        public override void OnErrorMethod(ExecutionArgs args)
        {
            Console.WriteLine("异常方法");
        }

        public override void OnExitsMethod(ExecutionArgs args)
        {
            Console.WriteLine("退出方法");
        }
    }
}
